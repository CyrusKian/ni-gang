# PHub Prototype

PHub is a hospital room management prototype with a Node.js/Express authentication and invitation backend. Room, patient, bed, cleaning, and assignment data remain in browser storage until the approved database design is provided.

## Project structure

```text
PHub_Prototype/
|-- public/                 # Browser-delivered HTML, stylesheets, and scripts
|   |-- index.html
|   `-- assets/
|       |-- css/
|       `-- js/
|-- server/
|   `-- index.js             # Express app, API routes, auth, and startup
|-- data/
|   `-- private/             # Ignored by Git; server-only account and runtime data
|       |-- accounts.jsonl
|       |-- invitations.json
|       |-- promotion-requests.json
|       `-- security-audit.json
|-- package.json
|-- package-lock.json
`-- README.md
```

The Express server serves only `public/`. Never place credentials, runtime state, or secrets inside `public/`.

## Run locally

1. Install Node.js 20 or later.
2. From this project directory, run `npm.cmd install`.
3. Seed the first System Admin from PowerShell environment variables (choose a unique password and do not commit it):
   Stop a running PHub server before running the one-time seed command.

   ```powershell
   $env:PHUB_ADMIN_USERNAME = Read-Host "Initial System Admin username"
   $securePassword = Read-Host "Initial System Admin password" -AsSecureString
   $passwordPointer = [Runtime.InteropServices.Marshal]::SecureStringToBSTR($securePassword)
   try {
       $env:PHUB_ADMIN_PASSWORD = [Runtime.InteropServices.Marshal]::PtrToStringBSTR($passwordPointer)
       npm.cmd run seed-admin
   } finally {
       [Runtime.InteropServices.Marshal]::ZeroFreeBSTR($passwordPointer)
       Remove-Item Env:PHUB_ADMIN_PASSWORD -ErrorAction SilentlyContinue
   }
   Remove-Item Env:PHUB_ADMIN_USERNAME -ErrorAction SilentlyContinue
   ```

4. Set a private session secret and start the app:

   ```powershell
   $secretBytes = [byte[]]::new(48)
   $random = [Security.Cryptography.RandomNumberGenerator]::Create()
   $random.GetBytes($secretBytes)
   $env:PHUB_SESSION_SECRET = [Convert]::ToBase64String($secretBytes)
   $random.Dispose()
   npm.cmd start
   ```

5. Open `http://localhost:3000`.

The `admin6767` login shortcut still reveals the separate admin form, but the server verifies credentials and the System Admin role. Normal and admin sign-in share the same server-side attempt throttling and generic authentication failure response.

## Backend behavior

- Account authentication, registration, invitations, role checks, promotion requests/decisions, staff account creation/deletion, login throttling, and audit events are handled by Express routes.
- The server-only `data/private/accounts.jsonl` stores salted scrypt password hashes. Existing legacy records were migrated there during the previous backend setup. Keep private backups outside the web root.
- New accounts are appended to the same temporary account store with scrypt hashes. Admin/Head Nurse invitation tokens are stored as hashes in `data/private/`, expire after 48 hours, and can be redeemed once for a Nurse account.
- Invitation links are browser-address links. For another device to use one, PHub must be reachable from that device using a configured host/reverse proxy; localhost links only work on the machine running the server.
- Set `PHUB_PUBLIC_URL` to the public HTTPS origin when deploying behind a reverse proxy so invitation links use the correct address.
- Session cookies are HTTP-only and SameSite strict. The default session store is process memory for local development; restart logs users out. Use HTTPS and a persistent session store before deployment.
- Keep everything in `data/private/`, `.env`, and passwords private. Do not use this prototype for real patient data.
- No database schema or migrations were created. The temporary TXT/JSON files must be replaced with repositories mapped to the finalized MySQL schema in the later database phase.

## Existing room prototype behavior

Room, patient, bed-level cleaning, nurse-per-room, and doctor-per-patient assignments persist in this browser's local storage. Discharging a patient or manually setting an available room to Cleaning creates cleaning tasks per affected bed; occupied beds in the ward are left alone. Cleaning tasks must be acknowledged before those beds become available again. Patient discharges remove that patient's doctor assignments. This remains prototype-only local data, not a shared or backed-up database.

PROJECT STRUCTURE

PHub_Prototype/
├── public/                  # Browser-served files
│   ├── index.html
│   └── assets/
│       ├── css/
│       └── js/
├── server/
│   └── index.js             # Express app and API
├── data/
│   └── private/             # Git-ignored server data
│       └── accounts.jsonl
├── package.json
├── package-lock.json
└── README.md

ADMIN ACCOUNT
user: UrdanetaSacredHeartHospital
pass: Admin_secure@123!