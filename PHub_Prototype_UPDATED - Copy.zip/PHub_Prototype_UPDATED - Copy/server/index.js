const crypto = require('node:crypto');
const fs = require('node:fs');
const path = require('node:path');
const express = require('express');
const session = require('express-session');

const root = path.resolve(__dirname, '..');
const publicDirectory = path.join(root, 'public');
const privateDataDirectory = path.join(root, 'data', 'private');
const accountFile = path.join(privateDataDirectory, 'accounts.jsonl');
const invitationsFile = path.join(privateDataDirectory, 'invitations.json');
const promotionRequestsFile = path.join(privateDataDirectory, 'promotion-requests.json');
const auditFile = path.join(privateDataDirectory, 'security-audit.json');
const app = express();
const port = Number(process.env.PORT) || 3000;
const secureCookie = process.env.NODE_ENV === 'production';
const sessionSecret = process.env.PHUB_SESSION_SECRET || crypto.randomBytes(48).toString('hex');
const scryptAsync = (password, salt) => new Promise((resolve, reject) => {
    crypto.scrypt(password, salt, 64, { N: 32768, r: 8, p: 1, maxmem: 64 * 1024 * 1024 }, (err, key) => {
        if (err) reject(err);
        else resolve(key.toString('hex'));
    });
});
const failedLogins = new Map();
let accounts = [];
let invitations = [];
let promotionRequests = [];

function normalizeUsername(value) {
    return typeof value === 'string' ? value.trim().toLowerCase() : '';
}

function normalizeRole(value) {
    if (value === 'System Admin' || value === 'Head Nurse' || value === 'Nurse') return value;
    return 'Nurse';
}

function readJson(file, fallback) {
    try {
        if (!fs.existsSync(file)) return fallback;
        const parsed = JSON.parse(fs.readFileSync(file, 'utf8'));
        return parsed;
    } catch (err) {
        throw new Error(`Could not read backend data file ${path.basename(file)}: ${err.message}`);
    }
}

function writeJsonAtomic(file, value) {
    const tempFile = `${file}.${process.pid}.tmp`;
    fs.writeFileSync(tempFile, `${JSON.stringify(value, null, 2)}\n`, { mode: 0o600 });
    fs.renameSync(tempFile, file);
}

function writeAccounts() {
    const lines = accounts.map(account => JSON.stringify(account));
    const tempFile = `${accountFile}.${process.pid}.tmp`;
    fs.writeFileSync(tempFile, `${lines.join('\n')}${lines.length ? '\n' : ''}`, { mode: 0o600 });
    fs.renameSync(tempFile, accountFile);
}

async function loadAccounts() {
    fs.mkdirSync(path.dirname(accountFile), { recursive: true });
    if (!fs.existsSync(accountFile)) {
        accounts = [];
        return;
    }

    const lines = fs.readFileSync(accountFile, 'utf8').split(/\r?\n/).filter(Boolean);
    const loaded = [];
    let hasLegacyRecords = false;

    for (const line of lines) {
        if (line.trimStart().startsWith('{')) {
            const record = JSON.parse(line);
            if (!record || typeof record.username !== 'string' ||
                typeof record.salt !== 'string' || !/^[0-9a-f]{32}$/i.test(record.salt) ||
                typeof record.passwordHash !== 'string' || !/^[0-9a-f]{128}$/i.test(record.passwordHash)) {
                throw new Error('The private account file contains an invalid hashed account record.');
            }
            loaded.push({
                username: normalizeUsername(record.username),
                fullName: typeof record.fullName === 'string' ? record.fullName : record.username,
                role: normalizeRole(record.role),
                status: record.status === 'disabled' ? 'disabled' : 'active',
                salt: record.salt,
                passwordHash: record.passwordHash,
                createdAt: record.createdAt || new Date().toISOString()
            });
            continue;
        }

        const fields = line.split(',');
        if (fields.length < 3 || !fields[0].trim() || !fields[1]) {
            throw new Error('The private legacy account file has an unsupported record. Back it up and repair it before startup.');
        }
        const username = normalizeUsername(fields[0]);
        const password = fields[1].trim();
        const legacyRole = fields.slice(2).join(',').trim();
        const salt = crypto.randomBytes(16).toString('hex');
        loaded.push({
            username,
            fullName: fields[0].trim(),
            role: normalizeRole(legacyRole),
            status: 'active',
            salt,
            passwordHash: await scryptAsync(password, salt),
            createdAt: new Date().toISOString()
        });
        hasLegacyRecords = true;
    }

    accounts = loaded;
    if (hasLegacyRecords) {
        writeAccounts();
        console.log(`Hashed ${loaded.length} legacy account password(s) in the private account file.`);
    }
}

function recordAudit(eventType, details = {}) {
    const events = readJson(auditFile, []);
    events.push({ id: crypto.randomUUID(), at: new Date().toISOString(), eventType, details });
    writeJsonAtomic(auditFile, events.slice(-1000));
}

function publicAccount(account) {
    return {
        username: account.username,
        fullName: account.fullName,
        role: account.role,
        status: account.status,
        createdAt: account.createdAt
    };
}

function currentAccount(req) {
    if (!req.session.accountUsername) return null;
    const account = accounts.find(item =>
        item.username === req.session.accountUsername && item.status === 'active'
    );
    if (!account) return null;
    req.session.accountRole = account.role;
    return account;
}

function requireAuth(req, res, next) {
    const account = currentAccount(req);
    if (!account) return res.status(401).json({ error: 'Authentication required.' });
    req.account = account;
    next();
}

function requireRoles(...roles) {
    return (req, res, next) => {
        if (!req.account || !roles.includes(req.account.role)) {
            return res.status(403).json({ error: 'You are not authorized to perform this action.' });
        }
        next();
    };
}

function requireSameOrigin(req, res, next) {
    const origin = req.get('Origin');
    if (origin) {
        try {
            if (new URL(origin).host !== req.get('host')) {
                return res.status(403).json({ error: 'Request origin is not allowed.' });
            }
        } catch {
            return res.status(403).json({ error: 'Request origin is not allowed.' });
        }
    }
    next();
}

function isValidUsername(username) {
    return /^[a-z0-9._-]{3,30}$/.test(username);
}

function generateOpaqueToken() {
    return crypto.randomBytes(32).toString('base64url');
}

function getPublicBaseUrl(req) {
    if (!process.env.PHUB_PUBLIC_URL) return `${req.protocol}://${req.get('host')}`;
    const publicUrl = new URL(process.env.PHUB_PUBLIC_URL);
    if (!['http:', 'https:'].includes(publicUrl.protocol) || publicUrl.username || publicUrl.password) {
        throw new Error('PHUB_PUBLIC_URL must be a valid HTTP(S) origin.');
    }
    if (process.env.NODE_ENV === 'production' && publicUrl.protocol !== 'https:') {
        throw new Error('PHUB_PUBLIC_URL must use HTTPS in production.');
    }
    return publicUrl.origin;
}

function tokenDigest(token) {
    return crypto.createHash('sha256').update(token).digest('hex');
}

function loginKey(ip, username) {
    return `${ip}:${normalizeUsername(username)}`;
}

function checkLoginLimit(key) {
    const state = failedLogins.get(key);
    if (!state) return false;
    const now = Date.now();
    if (state.windowEndsAt <= now) {
        failedLogins.delete(key);
        return false;
    }
    return state.lockUntil > now;
}

function noteFailedLogin(key, lockThreshold = 5) {
    const now = Date.now();
    const current = failedLogins.get(key);
    const state = current && current.windowEndsAt > now
        ? current
        : { failures: 0, windowEndsAt: now + 15 * 60 * 1000, lockUntil: 0 };
    state.failures += 1;
    if (state.failures >= lockThreshold) state.lockUntil = now + 10 * 60 * 1000;
    failedLogins.set(key, state);
}

function clearFailedLogin(key) {
    failedLogins.delete(key);
}

function validatePassword(password) {
    return typeof password === 'string' && password.length >= 8 && password.length <= 256;
}

async function seedAdmin(usernameValue, passwordValue) {
    if (accounts.some(account => account.role === 'System Admin')) {
        throw new Error('A System Admin account already exists.');
    }
    const username = normalizeUsername(usernameValue);
    const password = passwordValue;
    if (!isValidUsername(username) || !validatePassword(password)) {
        throw new Error('Set PHUB_ADMIN_USERNAME (3-30 valid characters) and PHUB_ADMIN_PASSWORD (at least 8 characters).');
    }
    if (accounts.some(account => account.username === username)) {
        throw new Error('The configured admin username already belongs to an account.');
    }
    const salt = crypto.randomBytes(16).toString('hex');
    const account = {
        username,
        fullName: 'System Administrator',
        role: 'System Admin',
        status: 'active',
        salt,
        passwordHash: await scryptAsync(password, salt),
        createdAt: new Date().toISOString()
    };
    accounts.push(account);
    writeAccounts();
    recordAudit('system-admin-seeded', { username });
    return account;
}

async function initialize(seedFromEnvironment = true) {
    await loadAccounts();
    invitations = readJson(invitationsFile, []);
    promotionRequests = readJson(promotionRequestsFile, []);

    if (!Array.isArray(invitations) || !Array.isArray(promotionRequests)) {
        throw new Error('Backend invitation or promotion data has an invalid format.');
    }

    if (seedFromEnvironment && !accounts.some(account => account.role === 'System Admin') &&
        process.env.PHUB_ADMIN_USERNAME && process.env.PHUB_ADMIN_PASSWORD) {
        await seedAdmin(process.env.PHUB_ADMIN_USERNAME, process.env.PHUB_ADMIN_PASSWORD);
        console.log('Initial System Admin account seeded from server environment configuration.');
    }
}

app.disable('x-powered-by');
app.use((req, res, next) => {
    res.setHeader('Referrer-Policy', 'no-referrer');
    if (req.path.startsWith('/api') || req.path === '/') {
        res.setHeader('Cache-Control', 'no-store');
    }
    next();
});
app.use(express.json({ limit: '16kb' }));
app.use(session({
    name: 'phub.sid',
    secret: sessionSecret,
    resave: false,
    saveUninitialized: false,
    cookie: {
        httpOnly: true,
        sameSite: 'strict',
        secure: secureCookie,
        maxAge: 8 * 60 * 60 * 1000
    }
}));
app.use('/api', requireSameOrigin);
app.use('/assets', express.static(path.join(publicDirectory, 'assets'), {
    dotfiles: 'deny',
    index: false,
    fallthrough: false
}));
app.get('/', (req, res) => res.sendFile(path.join(publicDirectory, 'index.html')));

app.get('/api/health', (req, res) => res.json({
    status: 'ok',
    systemAdminConfigured: accounts.some(account => account.role === 'System Admin' && account.status === 'active')
}));

app.get('/api/auth/session', (req, res) => {
    const account = currentAccount(req);
    res.json({ user: account ? publicAccount(account) : null });
});

app.post('/api/auth/login', async (req, res, next) => {
    try {
        const username = normalizeUsername(req.body.username);
        const password = req.body.password;
        const adminOnly = req.body.adminOnly === true;
        const key = loginKey(req.ip, username);
        const ipKey = `ip:${req.ip}`;
        if (checkLoginLimit(key) || checkLoginLimit(ipKey)) {
            recordAudit('login-blocked', { username, ip: req.ip, reason: 'cooldown' });
            return res.status(429).json({ error: 'Too many failed sign-in attempts. Try again later.' });
        }

        const account = accounts.find(item =>
            item.username === username && item.status === 'active'
        );
        const passwordIsValid = typeof password === 'string' && password.length > 0 && password.length <= 256;
        const candidateHash = await scryptAsync(passwordIsValid ? password : '', account ? account.salt : 'phub-login-dummy-salt');
        const validPassword = Boolean(account && passwordIsValid &&
            crypto.timingSafeEqual(Buffer.from(candidateHash, 'hex'), Buffer.from(account.passwordHash, 'hex')));
        const validRole = !adminOnly || (account && account.role === 'System Admin');
        if (!validPassword || !validRole) {
            noteFailedLogin(key);
            noteFailedLogin(ipKey, 20);
            recordAudit('login-failed', { username, ip: req.ip });
            return res.status(401).json({ error: 'Invalid username or password.' });
        }

        clearFailedLogin(key);
        clearFailedLogin(ipKey);
        await new Promise((resolve, reject) => req.session.regenerate(err => err ? reject(err) : resolve()));
        req.session.accountUsername = account.username;
        req.session.accountRole = account.role;
        recordAudit('login-success', { username, role: account.role, ip: req.ip });
        res.json({ user: publicAccount(account) });
    } catch (err) {
        next(err);
    }
});

app.post('/api/auth/logout', (req, res, next) => {
    const username = req.session.accountUsername;
    req.session.destroy(err => {
        if (err) return next(err);
        res.clearCookie('phub.sid', { httpOnly: true, sameSite: 'strict', secure: secureCookie });
        if (username) recordAudit('logout', { username });
        res.json({ ok: true });
    });
});

app.get('/api/invitations/validate', (req, res) => {
    const token = typeof req.query.token === 'string' ? req.query.token : '';
    const digest = tokenDigest(token);
    const invitation = invitations.find(item =>
        item.tokenHash === digest && !item.usedAt && new Date(item.expiresAt).getTime() > Date.now()
    );
    if (!invitation) return res.status(404).json({ error: 'Invitation is invalid or expired.' });
    res.json({ valid: true, role: 'Nurse', expiresAt: invitation.expiresAt });
});

app.post('/api/auth/register', async (req, res, next) => {
    try {
        const token = typeof req.body.invitationToken === 'string' ? req.body.invitationToken : '';
        const invitation = invitations.find(item =>
            item.tokenHash === tokenDigest(token) &&
            !item.usedAt &&
            new Date(item.expiresAt).getTime() > Date.now()
        );
        const fullName = typeof req.body.fullName === 'string' ? req.body.fullName.trim() : '';
        const username = normalizeUsername(req.body.username);
        const password = req.body.password;
        if (!invitation || !fullName || fullName.length > 80 ||
            !isValidUsername(username) || !validatePassword(password)) {
            return res.status(400).json({ error: 'Invitation or registration details are invalid.' });
        }
        if (accounts.some(account => account.username === username)) {
            return res.status(409).json({ error: 'That username is already registered.' });
        }

        const salt = crypto.randomBytes(16).toString('hex');
        const account = {
            username,
            fullName,
            role: 'Nurse',
            status: 'active',
            salt,
            passwordHash: await scryptAsync(password, salt),
            createdAt: new Date().toISOString()
        };
        const currentInvitation = invitations.find(item =>
            item.tokenHash === tokenDigest(token) &&
            !item.usedAt &&
            new Date(item.expiresAt).getTime() > Date.now()
        );
        if (!currentInvitation || accounts.some(item => item.username === username)) {
            return res.status(409).json({ error: 'Invitation was already used or the username is unavailable.' });
        }
        accounts.push(account);
        try {
            writeAccounts();
            currentInvitation.usedAt = new Date().toISOString();
            currentInvitation.usedBy = username;
            writeJsonAtomic(invitationsFile, invitations);
        } catch (err) {
            accounts = accounts.filter(item => item.username !== username);
            writeAccounts();
            throw err;
        }
        recordAudit('account-created', { username, role: 'Nurse', invitedBy: invitation.createdBy });
        await new Promise((resolve, reject) => req.session.regenerate(err => err ? reject(err) : resolve()));
        req.session.accountUsername = account.username;
        req.session.accountRole = account.role;
        res.status(201).json({ user: publicAccount(account) });
    } catch (err) {
        next(err);
    }
});

app.get('/api/invitations', requireAuth, requireRoles('System Admin', 'Head Nurse'), (req, res) => {
    const visibleInvites = invitations
        .filter(item => !item.usedAt && new Date(item.expiresAt).getTime() > Date.now())
        .map(item => ({
            createdAt: item.createdAt,
            expiresAt: item.expiresAt,
            createdBy: item.createdBy
        }));
    res.json({ invitations: visibleInvites });
});

app.post('/api/invitations', requireAuth, requireRoles('System Admin', 'Head Nurse'), (req, res) => {
    const origin = getPublicBaseUrl(req);
    const token = generateOpaqueToken();
    const now = new Date();
    const expiresAt = new Date(now.getTime() + 48 * 60 * 60 * 1000).toISOString();
    invitations.push({
        tokenHash: tokenDigest(token),
        createdAt: now.toISOString(),
        expiresAt,
        createdBy: req.account.username,
        usedAt: null,
        usedBy: null
    });
    writeJsonAtomic(invitationsFile, invitations);
    recordAudit('invitation-created', { createdBy: req.account.username, role: 'Nurse', expiresAt });
    res.status(201).json({ url: `${origin}/?invite=${encodeURIComponent(token)}`, role: 'Nurse', expiresAt });
});

app.get('/api/promotion-requests', requireAuth, requireRoles('System Admin', 'Head Nurse'), (req, res) => {
    res.json({
        requests: promotionRequests.filter(item => item.status === 'Pending')
    });
});

app.get('/api/promotion-requests/mine', requireAuth, (req, res) => {
    const request = promotionRequests
        .filter(item => item.requesterUsername === req.account.username)
        .sort((a, b) => new Date(b.submittedAt) - new Date(a.submittedAt))[0] || null;
    res.json({ request });
});

app.post('/api/promotion-requests', requireAuth, (req, res) => {
    if (req.account.role !== 'Nurse') {
        return res.status(403).json({ error: 'Only Nurses can request Head Nurse promotion.' });
    }
    const pending = promotionRequests.find(item =>
        item.requesterUsername === req.account.username && item.status === 'Pending'
    );
    if (pending) return res.status(409).json({ error: 'A promotion request is already pending.' });

    const request = {
        id: crypto.randomUUID(),
        requesterUsername: req.account.username,
        requesterName: req.account.fullName,
        requestedRole: 'Head Nurse',
        status: 'Pending',
        submittedAt: new Date().toISOString(),
        reviewedBy: null,
        decision: null,
        decisionDate: null
    };
    promotionRequests.push(request);
    writeJsonAtomic(promotionRequestsFile, promotionRequests);
    recordAudit('promotion-requested', { username: req.account.username });
    res.status(201).json({ request });
});

app.patch('/api/promotion-requests/:id', requireAuth, requireRoles('System Admin', 'Head Nurse'), (req, res) => {
    const decision = req.body.decision;
    if (!['Approved', 'Rejected'].includes(decision)) {
        return res.status(400).json({ error: 'Decision must be Approved or Rejected.' });
    }
    const request = promotionRequests.find(item => item.id === req.params.id && item.status === 'Pending');
    if (!request) return res.status(404).json({ error: 'Pending promotion request not found.' });
    if (request.requesterUsername === req.account.username) {
        return res.status(403).json({ error: 'You cannot review your own promotion request.' });
    }

    const account = accounts.find(item => item.username === request.requesterUsername);
    if (!account || account.status !== 'active') {
        return res.status(409).json({ error: 'The requesting account is no longer active.' });
    }
    request.status = decision;
    request.reviewedBy = req.account.username;
    request.decision = decision;
    request.decisionDate = new Date().toISOString();
    if (decision === 'Approved') account.role = 'Head Nurse';
    writeAccounts();
    writeJsonAtomic(promotionRequestsFile, promotionRequests);
    recordAudit('promotion-decision', { requestId: request.id, decision, reviewedBy: req.account.username });
    res.json({ request });
});

app.get('/api/users', requireAuth, requireRoles('System Admin'), (req, res) => {
    res.json({ users: accounts.map(publicAccount) });
});

app.post('/api/users', requireAuth, requireRoles('System Admin'), async (req, res, next) => {
    try {
        const fullName = typeof req.body.fullName === 'string' ? req.body.fullName.trim() : '';
        const username = normalizeUsername(req.body.username);
        const role = req.body.role;
        const password = req.body.password;
        if (!fullName || fullName.length > 80 || !isValidUsername(username) ||
            !['Nurse', 'Head Nurse'].includes(role) || !validatePassword(password)) {
            return res.status(400).json({ error: 'Staff account details are invalid.' });
        }
        if (accounts.some(item => item.username === username)) {
            return res.status(409).json({ error: 'That username is already registered.' });
        }
        const salt = crypto.randomBytes(16).toString('hex');
        const account = {
            username,
            fullName,
            role,
            status: 'active',
            salt,
            passwordHash: await scryptAsync(password, salt),
            createdAt: new Date().toISOString()
        };
        accounts.push(account);
        writeAccounts();
        recordAudit('admin-created-account', { username, role, createdBy: req.account.username });
        res.status(201).json({ user: publicAccount(account) });
    } catch (err) {
        next(err);
    }
});

app.delete('/api/users/:username', requireAuth, requireRoles('System Admin'), (req, res) => {
    const username = normalizeUsername(req.params.username);
    const target = accounts.find(item => item.username === username);
    if (!target || target.role === 'System Admin') {
        return res.status(404).json({ error: 'Nurse or Head Nurse account not found.' });
    }
    accounts = accounts.filter(item => item.username !== username);
    writeAccounts();
    recordAudit('admin-deleted-account', { username, deletedBy: req.account.username });
    res.json({ ok: true });
});

app.use((req, res) => {
    res.status(404).json({ error: 'Not found.' });
});

app.use((err, req, res, next) => {
    console.error('PHub request failed:', err.message);
    if (res.headersSent) return next(err);
    res.status(500).json({ error: 'The server could not complete the request.' });
});

async function main() {
    await initialize(process.argv[2] !== 'seed-admin');
    if (process.argv[2] === 'seed-admin') {
        await seedAdmin(process.env.PHUB_ADMIN_USERNAME, process.env.PHUB_ADMIN_PASSWORD);
        console.log('System Admin account created.');
        return;
    }
    app.listen(port, () => {
        console.log(`PHub server listening on http://localhost:${port}`);
        if (!process.env.PHUB_SESSION_SECRET) {
            console.warn('PHUB_SESSION_SECRET is not set; sessions will be invalidated when the server restarts.');
        }
        if (!accounts.some(account => account.role === 'System Admin')) {
            console.warn('No System Admin exists. Set PHUB_ADMIN_USERNAME and PHUB_ADMIN_PASSWORD, then run npm run seed-admin.');
        }
    });
}

main().catch(err => {
    console.error(`PHub backend failed to start: ${err.message}`);
    process.exitCode = 1;
});
