const mysql = require('mysql2/promise');

const requiredSettings = ['DB_HOST', 'DB_NAME', 'DB_USER', 'DB_PASSWORD'];
const missingSettings = requiredSettings.filter(setting => !process.env[setting]);

if (missingSettings.length) {
    throw new Error(`Missing required MySQL settings: ${missingSettings.join(', ')}`);
}

const port = process.env.DB_PORT ? Number(process.env.DB_PORT) : 3306;
if (!Number.isInteger(port) || port < 1 || port > 65535) {
    throw new Error('DB_PORT must be a valid TCP port number.');
}

const pool = mysql.createPool({
    host: process.env.DB_HOST,
    port,
    database: process.env.DB_NAME,
    user: process.env.DB_USER,
    password: process.env.DB_PASSWORD,
    timezone: 'Z',
    dateStrings: true,
    waitForConnections: true,
    connectionLimit: 10,
    queueLimit: 0
});

async function verifyConnection() {
    await pool.query('SELECT 1');
}

module.exports = { pool, verifyConnection };
