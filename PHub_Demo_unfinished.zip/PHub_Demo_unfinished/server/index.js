const crypto = require('node:crypto');
const fs = require('node:fs');
const path = require('node:path');
const express = require('express');
const session = require('express-session');

const root = path.resolve(__dirname, '..');
require('dotenv').config({ path: path.join(root, '.env') });
const database = require('./db');
const calendarRoutes = require('./calendar.routes');
const clinicalRoutes = require('./clinical.routes');
const workflowStore = require('./workflow-store');
const publicDirectory = path.join(root, 'public');
const privateDataDirectory = path.join(root, 'data', 'private');
const accountFile = path.join(privateDataDirectory, 'accounts.jsonl');
const invitationsFile = path.join(privateDataDirectory, 'invitations.json');
const promotionRequestsFile = path.join(privateDataDirectory, 'promotion-requests.json');
const auditFile = path.join(privateDataDirectory, 'security-audit.json');
const app = express();
const port = Number(process.env.PORT) || 3000;
const secureCookie = process.env.NODE_ENV === 'production';
const sessionSecret = process.env.PHUB_SESSION_SECRET || crypto.randomBytes(48).toString('hex');
const scryptAsync = (password, salt) => new Promise((resolve, reject) => {
    crypto.scrypt(password, salt, 64, { N: 32768, r: 8, p: 1, maxmem: 64 * 1024 * 1024 }, (err, key) => {
        if (err) reject(err);
        else resolve(key.toString('hex'));
    });
});
const failedLogins = new Map();
let accounts = [];

function normalizeUsername(value) {
    return typeof value === 'string' ? value.trim().toLowerCase() : '';
}

function normalizeRole(value) {
    if (value === 'System Admin' || value === 'Head Nurse' || value === 'Nurse') return value;
    return 'Nurse';
}

function readJson(file, fallback) {
    try {
        if (!fs.existsSync(file)) return fallback;
        const parsed = JSON.parse(fs.readFileSync(file, 'utf8'));
        return parsed;
    } catch (err) {
        throw new Error(`Could not read backend data file ${path.basename(file)}: ${err.message}`);
    }
}

function writeAccounts() {
    const lines = accounts.map(account => JSON.stringify(account));
    const tempFile = `${accountFile}.${process.pid}.tmp`;
    fs.writeFileSync(tempFile, `${lines.join('\n')}${lines.length ? '\n' : ''}`, { mode: 0o600 });
    fs.renameSync(tempFile, accountFile);
}

async function loadLegacyAccounts() {
    fs.mkdirSync(path.dirname(accountFile), { recursive: true });
    if (!fs.existsSync(accountFile)) {
        accounts = [];
        return;
    }

    const lines = fs.readFileSync(accountFile, 'utf8').split(/\r?\n/).filter(Boolean);
    const loaded = [];
    let hasLegacyRecords = false;

    for (const line of lines) {
        if (line.trimStart().startsWith('{')) {
            const record = JSON.parse(line);
            if (!record || typeof record.username !== 'string' ||
                typeof record.salt !== 'string' || !/^[0-9a-f]{32}$/i.test(record.salt) ||
                typeof record.passwordHash !== 'string' || !/^[0-9a-f]{128}$/i.test(record.passwordHash)) {
                throw new Error('The private account file contains an invalid hashed account record.');
            }
            loaded.push({
                username: normalizeUsername(record.username),
                fullName: typeof record.fullName === 'string' ? record.fullName : record.username,
                role: normalizeRole(record.role),
                status: record.status === 'disabled' ? 'disabled' : 'active',
                salt: record.salt,
                passwordHash: record.passwordHash,
                createdAt: record.createdAt || new Date().toISOString()
            });
            continue;
        }

        const fields = line.split(',');
        if (fields.length < 3 || !fields[0].trim() || !fields[1]) {
            throw new Error('The private legacy account file has an unsupported record. Back it up and repair it before startup.');
        }
        const username = normalizeUsername(fields[0]);
        const password = fields[1].trim();
        const legacyRole = fields.slice(2).join(',').trim();
        const salt = crypto.randomBytes(16).toString('hex');
        loaded.push({
            username,
            fullName: fields[0].trim(),
            role: normalizeRole(legacyRole),
            status: 'active',
            salt,
            passwordHash: await scryptAsync(password, salt),
            createdAt: new Date().toISOString()
        });
        hasLegacyRecords = true;
    }

    accounts = loaded;
    if (hasLegacyRecords) {
        writeAccounts();
        console.log(`Hashed ${loaded.length} legacy account password(s) in the private account file.`);
    }
}

async function recordAudit(eventType, details = {}) {
    await workflowStore.insertAuditEvent({
        id: crypto.randomUUID(),
        at: new Date().toISOString(),
        eventType,
        details
    });
}

function publicAccount(account) {
    return {
        username: account.username,
        fullName: account.fullName,
        role: account.role,
        status: account.status,
        createdAt: account.createdAt
    };
}

function currentAccount(req) {
    if (!req.session.accountUsername) return null;
    const account = accounts.find(item =>
        item.username === req.session.accountUsername && item.status === 'active'
    );
    if (!account) return null;
    req.session.accountRole = account.role;
    return account;
}

function requireAuth(req, res, next) {
    const account = currentAccount(req);
    if (!account) return res.status(401).json({ error: 'Authentication required.' });
    req.account = account;
    next();
}

function requireRoles(...roles) {
    return (req, res, next) => {
        if (!req.account || !roles.includes(req.account.role)) {
            return res.status(403).json({ error: 'You are not authorized to perform this action.' });
        }
        next();
    };
}

function requireSameOrigin(req, res, next) {
    const origin = req.get('Origin');
    if (origin) {
        try {
            if (new URL(origin).host !== req.get('host')) {
                return res.status(403).json({ error: 'Request origin is not allowed.' });
            }
        } catch {
            return res.status(403).json({ error: 'Request origin is not allowed.' });
        }
    }
    next();
}

function isValidUsername(username) {
    return /^[a-z0-9._-]{3,30}$/.test(username);
}

function generateOpaqueToken() {
    return crypto.randomBytes(32).toString('base64url');
}

function getPublicBaseUrl(req) {
    if (!process.env.PHUB_PUBLIC_URL) return `${req.protocol}://${req.get('host')}`;
    const publicUrl = new URL(process.env.PHUB_PUBLIC_URL);
    if (!['http:', 'https:'].includes(publicUrl.protocol) || publicUrl.username || publicUrl.password) {
        throw new Error('PHUB_PUBLIC_URL must be a valid HTTP(S) origin.');
    }
    if (process.env.NODE_ENV === 'production' && publicUrl.protocol !== 'https:') {
        throw new Error('PHUB_PUBLIC_URL must use HTTPS in production.');
    }
    return publicUrl.origin;
}

function tokenDigest(token) {
    return crypto.createHash('sha256').update(token).digest('hex');
}

function loginKey(ip, username) {
    return `${ip}:${normalizeUsername(username)}`;
}

function checkLoginLimit(key) {
    const state = failedLogins.get(key);
    if (!state) return false;
    const now = Date.now();
    if (state.windowEndsAt <= now) {
        failedLogins.delete(key);
        return false;
    }
    return state.lockUntil > now;
}

function noteFailedLogin(key, lockThreshold = 5) {
    const now = Date.now();
    const current = failedLogins.get(key);
    const state = current && current.windowEndsAt > now
        ? current
        : { failures: 0, windowEndsAt: now + 15 * 60 * 1000, lockUntil: 0 };
    state.failures += 1;
    if (state.failures >= lockThreshold) state.lockUntil = now + 10 * 60 * 1000;
    failedLogins.set(key, state);
}

function clearFailedLogin(key) {
    failedLogins.delete(key);
}

function validatePassword(password) {
    return typeof password === 'string' && password.length >= 8 && password.length <= 256;
}

async function seedAdmin(usernameValue, passwordValue) {
    if (accounts.some(account => account.role === 'System Admin')) {
        throw new Error('A System Admin account already exists.');
    }
    const username = normalizeUsername(usernameValue);
    const password = passwordValue;
    if (!isValidUsername(username) || !validatePassword(password)) {
        throw new Error('Set PHUB_ADMIN_USERNAME (3-30 valid characters) and PHUB_ADMIN_PASSWORD (at least 8 characters).');
    }
    if (accounts.some(account => account.username === username)) {
        throw new Error('The configured admin username already belongs to an account.');
    }
    const salt = crypto.randomBytes(16).toString('hex');
    const account = {
        username,
        fullName: 'System Administrator',
        role: 'System Admin',
        status: 'active',
        salt,
        passwordHash: await scryptAsync(password, salt),
        createdAt: new Date().toISOString()
    };
    await workflowStore.insertAccount(account);
    accounts.push(account);
    await recordAudit('system-admin-seeded', { username });
    return account;
}

async function initialize(seedFromEnvironment = true) {
    await loadLegacyAccounts();
    const legacyInvitations = readJson(invitationsFile, []);
    const legacyPromotionRequests = readJson(promotionRequestsFile, []);
    const legacyAuditEvents = readJson(auditFile, []);
    if (!Array.isArray(legacyInvitations) || !Array.isArray(legacyPromotionRequests) ||
        !Array.isArray(legacyAuditEvents)) {
        throw new Error('Backend invitation or promotion data has an invalid format.');
    }

    await workflowStore.migrateLegacyFiles({
        accounts,
        invitations: legacyInvitations,
        promotionRequests: legacyPromotionRequests,
        auditEvents: legacyAuditEvents
    });
    accounts = await workflowStore.loadAccounts();

    if (seedFromEnvironment && !accounts.some(account => account.role === 'System Admin') &&
        process.env.PHUB_ADMIN_USERNAME && process.env.PHUB_ADMIN_PASSWORD) {
        await seedAdmin(process.env.PHUB_ADMIN_USERNAME, process.env.PHUB_ADMIN_PASSWORD);
        console.log('Initial System Admin account seeded from server environment configuration.');
    }
}

app.disable('x-powered-by');
app.use((req, res, next) => {
    res.setHeader('Referrer-Policy', 'no-referrer');
    if (req.path.startsWith('/api') || req.path === '/') {
        res.setHeader('Cache-Control', 'no-store');
    }
    next();
});
app.use(express.json({ limit: '16kb' }));
app.use(session({
    name: 'phub.sid',
    secret: sessionSecret,
    resave: false,
    saveUninitialized: false,
    cookie: {
        httpOnly: true,
        sameSite: 'strict',
        secure: secureCookie,
        maxAge: 8 * 60 * 60 * 1000
    }
}));
app.use('/api', requireSameOrigin);
app.use('/api/calendar', requireAuth, requireRoles('Nurse', 'Head Nurse', 'System Admin'), calendarRoutes);
app.use('/api/clinical', requireAuth, requireRoles('Nurse', 'Head Nurse', 'System Admin'), clinicalRoutes);
app.use('/assets', express.static(path.join(publicDirectory, 'assets'), {
    dotfiles: 'deny',
    index: false,
    fallthrough: false
}));
app.get('/', (req, res) => res.sendFile(path.join(publicDirectory, 'index.html')));

app.get('/api/health', (req, res) => res.json({
    status: 'ok',
    systemAdminConfigured: accounts.some(account => account.role === 'System Admin' && account.status === 'active')
}));

app.get('/api/auth/session', (req, res) => {
    const account = currentAccount(req);
    res.json({ user: account ? publicAccount(account) : null });
});

app.post('/api/auth/login', async (req, res, next) => {
    try {
        const username = normalizeUsername(req.body.username);
        const password = req.body.password;
        const adminOnly = req.body.adminOnly === true;
        const key = loginKey(req.ip, username);
        const ipKey = `ip:${req.ip}`;
        if (checkLoginLimit(key) || checkLoginLimit(ipKey)) {
            await recordAudit('login-blocked', { username, ip: req.ip, reason: 'cooldown' });
            return res.status(429).json({ error: 'Too many failed sign-in attempts. Try again later.' });
        }

        const account = accounts.find(item =>
            item.username === username && item.status === 'active'
        );
        const passwordIsValid = typeof password === 'string' && password.length > 0 && password.length <= 256;
        const candidateHash = await scryptAsync(passwordIsValid ? password : '', account ? account.salt : 'phub-login-dummy-salt');
        const validPassword = Boolean(account && passwordIsValid &&
            crypto.timingSafeEqual(Buffer.from(candidateHash, 'hex'), Buffer.from(account.passwordHash, 'hex')));
        const validRole = !adminOnly || (account && account.role === 'System Admin');
        if (!validPassword || !validRole) {
            noteFailedLogin(key);
            noteFailedLogin(ipKey, 20);
            await recordAudit('login-failed', { username, ip: req.ip });
            return res.status(401).json({ error: 'Invalid username or password.' });
        }

        clearFailedLogin(key);
        clearFailedLogin(ipKey);
        await new Promise((resolve, reject) => req.session.regenerate(err => err ? reject(err) : resolve()));
        req.session.accountUsername = account.username;
        req.session.accountRole = account.role;
        await recordAudit('login-success', { username, role: account.role, ip: req.ip });
        res.json({ user: publicAccount(account) });
    } catch (err) {
        next(err);
    }
});

app.post('/api/auth/logout', async (req, res, next) => {
    const username = req.session.accountUsername;
    try {
        await new Promise((resolve, reject) => req.session.destroy(err => err ? reject(err) : resolve()));
        res.clearCookie('phub.sid', { httpOnly: true, sameSite: 'strict', secure: secureCookie });
        if (username) await recordAudit('logout', { username });
        res.json({ ok: true });
    } catch (err) {
        next(err);
    }
});

app.get('/api/invitations/validate', async (req, res, next) => {
    try {
        const token = typeof req.query.token === 'string' ? req.query.token : '';
        const invitation = await workflowStore.validateInvitation(tokenDigest(token));
        if (!invitation) return res.status(404).json({ error: 'Invitation is invalid or expired.' });
        res.json({ valid: true, role: 'Nurse', expiresAt: invitation.expiresAt });
    } catch (err) {
        next(err);
    }
});

app.post('/api/auth/register', async (req, res, next) => {
    try {
        const token = typeof req.body.invitationToken === 'string' ? req.body.invitationToken : '';
        const invitationHash = tokenDigest(token);
        const invitation = await workflowStore.validateInvitation(invitationHash);
        const fullName = typeof req.body.fullName === 'string' ? req.body.fullName.trim() : '';
        const username = normalizeUsername(req.body.username);
        const password = req.body.password;
        if (!invitation || !fullName || fullName.length > 80 ||
            !isValidUsername(username) || !validatePassword(password)) {
            return res.status(400).json({ error: 'Invitation or registration details are invalid.' });
        }
        const salt = crypto.randomBytes(16).toString('hex');
        const account = {
            username,
            fullName,
            role: 'Nurse',
            status: 'active',
            salt,
            passwordHash: await scryptAsync(password, salt),
            createdAt: new Date().toISOString()
        };
        const registration = await workflowStore.redeemInvitation(invitationHash, account);
        if (registration === 'username') {
            return res.status(409).json({ error: 'That username is already registered.' });
        }
        if (registration !== 'created') {
            return res.status(409).json({ error: 'Invitation was already used or has expired.' });
        }
        accounts.push(account);
        await recordAudit('account-created', { username, role: 'Nurse', invitedBy: invitation.createdBy });
        await new Promise((resolve, reject) => req.session.regenerate(err => err ? reject(err) : resolve()));
        req.session.accountUsername = account.username;
        req.session.accountRole = account.role;
        res.status(201).json({ user: publicAccount(account) });
    } catch (err) {
        next(err);
    }
});

app.get('/api/invitations', requireAuth, requireRoles('System Admin', 'Head Nurse'), async (req, res, next) => {
    try {
        res.json({ invitations: await workflowStore.listValidInvitations() });
    } catch (err) {
        next(err);
    }
});

app.post('/api/invitations', requireAuth, requireRoles('System Admin', 'Head Nurse'), async (req, res, next) => {
    try {
        const origin = getPublicBaseUrl(req);
        const token = generateOpaqueToken();
        const now = new Date();
        const expiresAt = new Date(now.getTime() + 48 * 60 * 60 * 1000).toISOString();
        await workflowStore.insertInvitation({
            tokenHash: tokenDigest(token),
            createdAt: now.toISOString(),
            expiresAt,
            createdBy: req.account.username
        });
        await recordAudit('invitation-created', { createdBy: req.account.username, role: 'Nurse', expiresAt });
        res.status(201).json({ url: `${origin}/?invite=${encodeURIComponent(token)}`, role: 'Nurse', expiresAt });
    } catch (err) {
        next(err);
    }
});

app.get('/api/promotion-requests', requireAuth, requireRoles('System Admin', 'Head Nurse'), async (req, res, next) => {
    try {
        res.json({ requests: await workflowStore.listPendingPromotionRequests() });
    } catch (err) {
        next(err);
    }
});

app.get('/api/promotion-requests/mine', requireAuth, async (req, res, next) => {
    try {
        res.json({ request: await workflowStore.latestPromotionRequest(req.account.username) });
    } catch (err) {
        next(err);
    }
});

app.post('/api/promotion-requests', requireAuth, async (req, res, next) => {
    if (req.account.role !== 'Nurse') {
        return res.status(403).json({ error: 'Only Nurses can request Head Nurse promotion.' });
    }
    const request = {
        id: crypto.randomUUID(),
        requesterUsername: req.account.username,
        requesterName: req.account.fullName,
        requestedRole: 'Head Nurse',
        status: 'Pending',
        submittedAt: new Date().toISOString(),
        reviewedBy: null,
        decision: null,
        decisionDate: null
    };
    try {
        if (!await workflowStore.createPromotionRequest(request)) {
            return res.status(409).json({ error: 'A promotion request is already pending.' });
        }
        await recordAudit('promotion-requested', { username: req.account.username });
        res.status(201).json({ request });
    } catch (err) {
        next(err);
    }
});

app.patch('/api/promotion-requests/:id', requireAuth, requireRoles('System Admin', 'Head Nurse'), async (req, res, next) => {
    const decision = req.body.decision;
    if (!['Approved', 'Rejected'].includes(decision)) {
        return res.status(400).json({ error: 'Decision must be Approved or Rejected.' });
    }
    try {
        const result = await workflowStore.decidePromotionRequest(
            req.params.id, decision, req.account.username
        );
        if (result.error === 'not-found') {
            return res.status(404).json({ error: 'Pending promotion request not found.' });
        }
        if (result.error === 'self-review') {
            return res.status(403).json({ error: 'You cannot review your own promotion request.' });
        }
        if (result.error === 'inactive-account') {
            return res.status(409).json({ error: 'The requesting account is no longer active.' });
        }
        if (result.promotedUsername) {
            const account = accounts.find(item => item.username === result.promotedUsername);
            if (account) account.role = 'Head Nurse';
        }
        await recordAudit('promotion-decision', {
            requestId: result.request.id, decision, reviewedBy: req.account.username
        });
        res.json({ request: result.request });
    } catch (err) {
        next(err);
    }
});

app.get('/api/users', requireAuth, requireRoles('System Admin'), async (req, res, next) => {
    try {
        const users = await workflowStore.listAccounts();
        res.json({ users: users.map(publicAccount) });
    } catch (err) {
        next(err);
    }
});

app.post('/api/users', requireAuth, requireRoles('System Admin'), async (req, res, next) => {
    try {
        const fullName = typeof req.body.fullName === 'string' ? req.body.fullName.trim() : '';
        const username = normalizeUsername(req.body.username);
        const role = req.body.role;
        const password = req.body.password;
        if (!fullName || fullName.length > 80 || !isValidUsername(username) ||
            !['Nurse', 'Head Nurse'].includes(role) || !validatePassword(password)) {
            return res.status(400).json({ error: 'Staff account details are invalid.' });
        }
        const salt = crypto.randomBytes(16).toString('hex');
        const account = {
            username,
            fullName,
            role,
            status: 'active',
            salt,
            passwordHash: await scryptAsync(password, salt),
            createdAt: new Date().toISOString()
        };
        try {
            await workflowStore.insertAccount(account);
        } catch (err) {
            if (err.code === 'ER_DUP_ENTRY') {
                return res.status(409).json({ error: 'That username is already registered.' });
            }
            throw err;
        }
        accounts.push(account);
        await recordAudit('admin-created-account', { username, role, createdBy: req.account.username });
        res.status(201).json({ user: publicAccount(account) });
    } catch (err) {
        next(err);
    }
});

app.delete('/api/users/:username', requireAuth, requireRoles('System Admin'), async (req, res, next) => {
    const username = normalizeUsername(req.params.username);
    const target = accounts.find(item => item.username === username);
    if (!target || target.role === 'System Admin') {
        return res.status(404).json({ error: 'Nurse or Head Nurse account not found.' });
    }
    try {
        if (!await workflowStore.deleteAccount(username)) {
            return res.status(404).json({ error: 'Nurse or Head Nurse account not found.' });
        }
        accounts = accounts.filter(item => item.username !== username);
        await recordAudit('admin-deleted-account', { username, deletedBy: req.account.username });
        res.json({ ok: true });
    } catch (err) {
        next(err);
    }
});

app.use((req, res) => {
    res.status(404).json({ error: 'Not found.' });
});

app.use((err, req, res, next) => {
    if (res.headersSent) return next(err);
    const status = Number.isInteger(err.status) && err.status >= 400 && err.status <= 599
        ? err.status
        : Number.isInteger(err.code) && err.code >= 400 && err.code <= 599
            ? err.code
            : 500;
    if (status >= 500) console.error('PHub request failed:', err);
    res.status(status).json({
        error: status >= 500 ? 'The server could not complete the request.' : err.message
    });
});

async function main() {
    await database.verifyConnection();
    console.log('Connected to the configured MySQL database.');
    try {
        await initialize(process.argv[2] !== 'seed-admin');
    } catch (err) {
        if (err.code === 'ER_NO_SUCH_TABLE') {
            throw new Error('Required PHub workflow tables are missing. Apply database/migrations/001_add_phub_workflow_tables.sql with a MySQL account that has CREATE permission.');
        }
        throw err;
    }
    if (process.argv[2] === 'seed-admin') {
        await seedAdmin(process.env.PHUB_ADMIN_USERNAME, process.env.PHUB_ADMIN_PASSWORD);
        console.log('System Admin account created.');
        return;
    }
    app.listen(port, () => {
        console.log(`PHub server listening on http://localhost:${port}`);
        if (!process.env.PHUB_SESSION_SECRET) {
            console.warn('PHUB_SESSION_SECRET is not set; sessions will be invalidated when the server restarts.');
        }
        if (!accounts.some(account => account.role === 'System Admin')) {
            console.warn('No System Admin exists. Set PHUB_ADMIN_USERNAME and PHUB_ADMIN_PASSWORD, then run npm run seed-admin.');
        }
    });
}

main().catch(async err => {
    console.error(`PHub backend failed to start: ${err.message}`);
    try {
        await database.pool.end();
    } catch (closeError) {
        console.error(`Could not close the MySQL connection pool: ${closeError.message}`);
    }
    process.exitCode = 1;
});
