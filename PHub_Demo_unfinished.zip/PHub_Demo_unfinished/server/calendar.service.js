'use strict';

const path = require('node:path');
const { google } = require('googleapis');

const CALENDAR_ID = process.env.GOOGLE_CALENDAR_ID;
const TIMEZONE = process.env.TIMEZONE || 'Asia/Manila';

const auth = new google.auth.GoogleAuth({
  keyFile: process.env.GOOGLE_APPLICATION_CREDENTIALS ||
    path.join(__dirname, '..', 'data', 'private', 'phub-512607-e147d4d04231.json'),
  scopes: ['https://www.googleapis.com/auth/calendar'],
});
const calendar = google.calendar({ version: 'v3', auth });

class HttpError extends Error {
  constructor(status, message) {
    super(message);
    this.status = status;
  }
}

// Accepts an array or a comma separated string
const toList = (v) => (Array.isArray(v) ? v : String(v || '').split(',')).map((s) => String(s).trim()).filter(Boolean);
function parseList(v) {
  try { const a = JSON.parse(v); return Array.isArray(a) ? a : []; } catch (e) { return []; }
}
const iso = (d) => new Date(d).toISOString();
const when = (d) => ({ dateTime: iso(d), timeZone: TIMEZONE });

// Title shows the room and who is assigned; the description repeats it for people reading Google Calendar
function compose({ roomName, doctors, nurses, notes }) {
  const staff = [];
  if (doctors.length) staff.push(`Doctor: ${doctors.join(', ')}`);
  if (nurses.length) staff.push(`Nurse: ${nurses.join(', ')}`);
  return {
    summary: [roomName, staff.join(' / ')].filter(Boolean).join(' - '),
    description: [...staff, notes].filter(Boolean).join('\n'),
  };
}

function formatEvent(e) {
  const p = (e.extendedProperties && e.extendedProperties.private) || {};
  return {
    id: e.id,
    summary: e.summary,
    start: e.start && e.start.dateTime,
    end: e.end && e.end.dateTime,
    roomId: p.roomId,
    roomName: p.roomName,
    doctors: parseList(p.doctors),
    nurses: parseList(p.nurses),
    notes: p.notes || '',
    status: p.status || 'scheduled', // 'scheduled' | 'done'
    link: e.htmlLink,
  };
}

async function getRaw(eventId) {
  const res = await calendar.events.get({ calendarId: CALENDAR_ID, eventId });
  return res.data;
}

async function listEvents({ from, to, roomId }) {
  if (!CALENDAR_ID) throw new Error('GOOGLE_CALENDAR_ID is required to use the calendar API.');
  const res = await calendar.events.list({
    calendarId: CALENDAR_ID,
    timeMin: iso(from),
    timeMax: iso(to),
    singleEvents: true,
    orderBy: 'startTime',
    maxResults: 250,
    privateExtendedProperty: roomId ? [`roomId=${roomId}`] : undefined,
  });
  return (res.data.items || []).map(formatEvent);
}

// A room is free if no assignment overlaps the dates. Assignments marked done no longer hold the room.
async function isRoomAvailable({ roomId, start, end, excludeEventId }) {
  const events = await listEvents({ from: start, to: end, roomId });
  return !events.some((e) => e.id !== excludeEventId && e.status !== 'done');
}

async function createAssignment({ roomId, roomName, start, end, doctors, nurses, notes }) {
  if (!(await isRoomAvailable({ roomId, start, end }))) {
    throw new HttpError(409, 'This room is already assigned for those dates');
  }
  const d = toList(doctors);
  const n = toList(nurses);
  const name = roomName || `Room ${roomId}`;
  const { summary, description } = compose({ roomName: name, doctors: d, nurses: n, notes });

  const res = await calendar.events.insert({
    calendarId: CALENDAR_ID,
    requestBody: {
      summary,
      description,
      start: when(start),
      end: when(end),
      extendedProperties: {
        private: {
          roomId: String(roomId), roomName: name, doctors: JSON.stringify(d), nurses: JSON.stringify(n),
          notes: notes || '', status: 'scheduled',
        },
      },
    },
  });
  return formatEvent(res.data);
}

async function updateAssignment(eventId, body) {
  const cur = await getRaw(eventId);
  const p = (cur.extendedProperties && cur.extendedProperties.private) || {};
  if (p.status === 'done') throw new HttpError(409, 'This assignment is already marked done');

  const start = body.start || cur.start.dateTime;
  const end = body.end || cur.end.dateTime;
  if ((body.start || body.end) && !(await isRoomAvailable({ roomId: p.roomId, start, end, excludeEventId: eventId }))) {
    throw new HttpError(409, 'This room is already assigned for those dates');
  }

  const doctors = body.doctors !== undefined ? toList(body.doctors) : parseList(p.doctors);
  const nurses = body.nurses !== undefined ? toList(body.nurses) : parseList(p.nurses);
  const notes = body.notes !== undefined ? body.notes : p.notes || '';
  const { summary, description } = compose({ roomName: p.roomName || `Room ${p.roomId}`, doctors, nurses, notes });

  const res = await calendar.events.patch({
    calendarId: CALENDAR_ID,
    eventId,
    requestBody: {
      summary, description, start: when(start), end: when(end),
      extendedProperties: { private: { ...p, doctors: JSON.stringify(doctors), nurses: JSON.stringify(nurses), notes } },
    },
  });
  return formatEvent(res.data);
}

// The "Done" button: acknowledge that the assignment is finished
async function markDone(eventId) {
  const cur = await getRaw(eventId);
  const p = (cur.extendedProperties && cur.extendedProperties.private) || {};
  if (p.status === 'done') return formatEvent(cur);
  const res = await calendar.events.patch({
    calendarId: CALENDAR_ID,
    eventId,
    requestBody: {
      summary: `${cur.summary} [Done]`,
      extendedProperties: { private: { ...p, status: 'done', doneAt: new Date().toISOString() } },
    },
  });
  return formatEvent(res.data);
}

async function deleteAssignment(eventId) {
  await calendar.events.delete({ calendarId: CALENDAR_ID, eventId });
}

module.exports = { HttpError, listEvents, isRoomAvailable, createAssignment, updateAssignment, markDone, deleteAssignment };
