CREATE TABLE IF NOT EXISTS `phub_accounts` (
    `username` VARCHAR(30) NOT NULL,
    `full_name` VARCHAR(80) NOT NULL,
    `role` ENUM('System Admin', 'Head Nurse', 'Nurse') NOT NULL,
    `status` ENUM('active', 'disabled') NOT NULL DEFAULT 'active',
    `salt` CHAR(32) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
    `password_hash` CHAR(128) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
    `created_at` DATETIME(3) NOT NULL,
    PRIMARY KEY (`username`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

CREATE TABLE IF NOT EXISTS `phub_invitations` (
    `token_hash` CHAR(64) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
    `created_at` DATETIME(3) NOT NULL,
    `expires_at` DATETIME(3) NOT NULL,
    `created_by` VARCHAR(30) NOT NULL,
    `used_at` DATETIME(3) NULL,
    `used_by` VARCHAR(30) NULL,
    PRIMARY KEY (`token_hash`),
    KEY `idx_phub_invitations_expiry` (`expires_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

CREATE TABLE IF NOT EXISTS `phub_promotion_requests` (
    `id` CHAR(36) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
    `requester_username` VARCHAR(30) NOT NULL,
    `requester_name` VARCHAR(80) NOT NULL,
    `requested_role` ENUM('Head Nurse') NOT NULL,
    `status` ENUM('Pending', 'Approved', 'Rejected') NOT NULL,
    `submitted_at` DATETIME(3) NOT NULL,
    `reviewed_by` VARCHAR(30) NULL,
    `decision` ENUM('Approved', 'Rejected') NULL,
    `decision_date` DATETIME(3) NULL,
    PRIMARY KEY (`id`),
    KEY `idx_phub_promotion_requester` (`requester_username`, `submitted_at`),
    KEY `idx_phub_promotion_status` (`status`, `submitted_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

CREATE TABLE IF NOT EXISTS `phub_security_audit` (
    `id` CHAR(36) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
    `at` DATETIME(3) NOT NULL,
    `event_type` VARCHAR(80) NOT NULL,
    `details` JSON NOT NULL,
    PRIMARY KEY (`id`),
    KEY `idx_phub_audit_at` (`at`),
    KEY `idx_phub_audit_event` (`event_type`, `at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

CREATE TABLE IF NOT EXISTS `phub_cleaning_schedules` (
    `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    `Bed_id` VARCHAR(20) NOT NULL,
    `starts_at` DATETIME NOT NULL,
    `ends_at` DATETIME NOT NULL,
    `status` VARCHAR(40) NOT NULL DEFAULT 'Cleaning Scheduled',
    PRIMARY KEY (`id`),
    UNIQUE KEY `uq_phub_cleaning_bed` (`Bed_id`),
    KEY `idx_phub_cleaning_times` (`starts_at`, `ends_at`),
    CONSTRAINT `fk_phub_cleaning_bed`
        FOREIGN KEY (`Bed_id`) REFERENCES `beds` (`Bed_id`)
        ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
