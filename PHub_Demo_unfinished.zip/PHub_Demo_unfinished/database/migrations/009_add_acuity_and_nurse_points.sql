-- Adds acuity and room-floor data without dropping tables or deleting rows.
-- Existing patients are preserved and receive the safe baseline acuity level 1.

ALTER TABLE patients
    ADD COLUMN Acuity_Level ENUM('1', '2', '3', '4', '5') NOT NULL DEFAULT '1'
    AFTER Emergency_contact;

ALTER TABLE patients
    MODIFY COLUMN Acuity_Level ENUM('1', '2', '3', '4', '5') NOT NULL;

ALTER TABLE rooms
    ADD COLUMN Floor INT NOT NULL DEFAULT 1
    AFTER Room_type;

UPDATE rooms
SET Floor = CASE
    WHEN Room_id REGEXP '^[2]' THEN 2
    WHEN Room_id REGEXP '^[3]' THEN 3
    ELSE 1
END;

ALTER TABLE rooms
    MODIFY COLUMN Floor INT NOT NULL;

CREATE OR REPLACE VIEW nurse_assignment_load AS
SELECT
    n.Nurse_id,
    CONCAT_WS(' ', n.F_name, n.M_name, n.L_name) AS Nurse_name,
    COALESCE(SUM(room_load.room_points / room_load.nurse_count), 0) AS Current_points,
    COUNT(DISTINCT CASE WHEN pa.discharge IS NULL THEN pa.Patient_id END) AS Active_patient_count,
    COUNT(DISTINCT CASE WHEN na.Room_id IS NOT NULL THEN na.Room_id END) AS Assigned_room_count,
    GROUP_CONCAT(DISTINCT r.Floor ORDER BY r.Floor) AS Assigned_floors
FROM nurses n
LEFT JOIN nurse_assignment na ON na.Nurse_id = n.Nurse_id
LEFT JOIN rooms r ON r.Room_id = na.Room_id
LEFT JOIN (
    SELECT assigned.Room_id,
           COALESCE((
               SELECT SUM(CAST(patient.Acuity_Level AS UNSIGNED))
               FROM beds room_bed
               JOIN patient_assignment active_assignment
                   ON active_assignment.Bed_id = room_bed.Bed_id
                  AND active_assignment.discharge IS NULL
               JOIN patients patient ON patient.Patient_id = active_assignment.Patient_id
               WHERE room_bed.Room_id = assigned.Room_id
           ), 0) AS room_points,
           COUNT(DISTINCT assigned.Nurse_id) AS nurse_count
    FROM nurse_assignment assigned
    GROUP BY assigned.Room_id
) room_load ON room_load.Room_id = na.Room_id
LEFT JOIN beds b ON b.Room_id = na.Room_id
LEFT JOIN patient_assignment pa ON pa.Bed_id = b.Bed_id AND pa.discharge IS NULL
GROUP BY n.Nurse_id, n.F_name, n.M_name, n.L_name;

CREATE OR REPLACE VIEW nurse_room_suggestions AS
SELECT
    target.Room_id,
    target.Floor AS Target_floor,
    load_data.Nurse_id,
    load_data.Nurse_name,
    load_data.Current_points,
    load_data.Active_patient_count,
    load_data.Assigned_room_count,
    CASE
        WHEN EXISTS (
            SELECT 1
            FROM nurse_assignment same_floor_assignment
            JOIN rooms same_floor_room ON same_floor_room.Room_id = same_floor_assignment.Room_id
            WHERE same_floor_assignment.Nurse_id = load_data.Nurse_id
              AND same_floor_room.Floor = target.Floor
        ) THEN 1
        WHEN load_data.Assigned_room_count = 0 THEN 2
        ELSE 3
    END AS Proximity_group,
    COALESCE((
        SELECT MIN(ABS(other_floor.Floor - target.Floor))
        FROM nurse_assignment other_assignment
        JOIN rooms other_floor ON other_floor.Room_id = other_assignment.Room_id
        WHERE other_assignment.Nurse_id = load_data.Nurse_id
    ), 0) AS Floor_distance
FROM rooms target
CROSS JOIN nurse_assignment_load load_data
ORDER BY Proximity_group, Floor_distance, Current_points, Nurse_name;
