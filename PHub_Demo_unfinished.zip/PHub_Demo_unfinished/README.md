# PHub Prototype

PHub is a hospital room management prototype with a Node.js/Express backend. Clinical records use the existing MySQL schema. PHub account, invitation, promotion, audit, and cleaning-schedule workflows use five additive MySQL tables; the existing clinical tables are not altered.

## Apply the workflow migration

The application database account needs `SELECT`, `INSERT`, `UPDATE`, and `DELETE` privileges. It does not need DDL privileges at runtime. Apply the migration once using a MySQL account that has `CREATE` permission on `phub_db`:

```powershell
$mysqlAdmin = Read-Host "MySQL administrator username"
Get-Content -Raw "database\migrations\001_add_phub_workflow_tables.sql" |
    mysql.exe --host=127.0.0.1 --port=3307 "--user=$mysqlAdmin" --password phub_db
```

The migration uses `CREATE TABLE IF NOT EXISTS` and only adds `phub_accounts`, `phub_invitations`, `phub_promotion_requests`, `phub_security_audit`, and `phub_cleaning_schedules`. It does not modify existing clinical tables or insert sample records. Review and back up the database before applying schema changes.

On startup, PHub imports legacy account, invitation, promotion-request, and audit records from `data/private/` only when the corresponding MySQL table is empty. It leaves those private files in place as backups and never overwrites non-empty MySQL tables. Existing browser-local cleaning schedules are offered for a one-time import after sign-in, and are removed from that browser only after a successful import. If MySQL already has cleaning schedules, the local copy is preserved and the app reports that it was not imported.

## Run locally

1. Install Node.js 20 or later.
2. From this project directory, run `npm.cmd install`.
3. Configure `.env` with `DB_HOST`, `DB_PORT`, `DB_NAME`, `DB_USER`, and `DB_PASSWORD`.
4. Create the first System Admin using the secure PowerShell seeding steps below. Stop a running PHub server before running the one-time seed command.

   ```powershell
   $env:PHUB_ADMIN_USERNAME = Read-Host "Initial System Admin username"
   $securePassword = Read-Host "Initial System Admin password" -AsSecureString
   $passwordPointer = [Runtime.InteropServices.Marshal]::SecureStringToBSTR($securePassword)
   try {
       $env:PHUB_ADMIN_PASSWORD = [Runtime.InteropServices.Marshal]::PtrToStringBSTR($passwordPointer)
       npm.cmd run seed-admin
   } finally {
       [Runtime.InteropServices.Marshal]::ZeroFreeBSTR($passwordPointer)
       Remove-Item Env:PHUB_ADMIN_PASSWORD -ErrorAction SilentlyContinue
   }
   Remove-Item Env:PHUB_ADMIN_USERNAME -ErrorAction SilentlyContinue
   ```

5. Set a private session secret and start PHub:

   ```powershell
   $secretBytes = [byte[]]::new(48)
   $random = [Security.Cryptography.RandomNumberGenerator]::Create()
   $random.GetBytes($secretBytes)
   $env:PHUB_SESSION_SECRET = [Convert]::ToBase64String($secretBytes)
   $random.Dispose()
   npm.cmd start
   ```

6. Open `http://localhost:3000`.

## Backend behavior

- Clinical rooms, beds, patients, doctors, nurses, and assignments use the existing MySQL tables. Patient admission and discharge are transactional; discharge also creates or updates the bed's cleaning schedule in the same transaction.
- Cleaning schedules are shared through MySQL. The backend updates bed status as a schedule starts, prevents admission to a bed whose cleaning period has started, and changes a bed back to available only when its task is marked complete.
- PHub account credentials use salted scrypt hashes. Invitation tokens are stored as hashes, expire after 48 hours, and can be redeemed once for a Nurse account. Account, invitation, promotion, audit, and cleaning records are not seeded with demo data.
- Account access profiles are separate from the `nurses` clinical roster records.
- The server serves only `public/`. Keep `.env`, `data/private/`, and service-account credentials private. Keep the private JSON files as backups until the database migration has been verified.
- Session cookies are HTTP-only and SameSite strict. The default session store is process memory for local development, so a restart logs users out. Use HTTPS and a persistent session store before deployment.
- Google Calendar configuration uses `.env` (`GOOGLE_CALENDAR_ID` and optional `TIMEZONE`) and a service-account JSON in `data/private/`. Enable Google Calendar API access and grant the service account permission to manage the configured calendar.
- PHub is a prototype and must not be used with real patient data.
